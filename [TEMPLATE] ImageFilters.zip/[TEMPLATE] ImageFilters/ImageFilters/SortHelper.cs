﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ImageFilters
{
    class SortHelper
    {

        public static byte Kth_element(Byte[] Array)
        {
            //TODO: Implement Kth smallest/largest element
            // 1) Search the input array for the MIN and MAX elements without sorting
            // 2) Get the avarage of the numbers excluding the MIN and MAX elements

            // Remove the next line
            throw new NotImplementedException();
        }

        public static Byte[] CountingSort(Byte[] Array)    
        {
            // TODO: Implement the Counting Sort alogrithm on the input array

            // Remove the next line
            throw new NotImplementedException();
        }

        public static byte[] QuickSort(Byte[] Array)
        {
            // TODO: Implement the Quick Sort alogrithm on the input array

            // Remove the next line
            throw new NotImplementedException();
        }
    }
}
